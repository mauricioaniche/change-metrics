class FileA {
  private int c;
  private int a;
  private int b;
}

