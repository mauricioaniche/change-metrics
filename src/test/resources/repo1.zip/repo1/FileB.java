class FileB {
  private int b;

}

